window.onload = function(){
    
    $("#myhtml").css("background-color","pink");
    $("#mycss").css("background-color","pink");
    $("#myjs").css("background-color","pink");
    $("#myoutput").css("background-color","pink");
    $("#field1").css("display","block");
    $("#field2").css("display","block");
    $("#field3").css("display","block");
    $("#field4").css("display","block");
    $("button").each(function(index,value){
        $(value).click(function(){
            console.log($(this).css("background-color"))
            if($(this).css("background-color")==="rgb(255, 192, 203)")
            {
                $(this).css("background-color","white");
                switch(index) {
                    case 0:
                        $("#field1").css("display","none");
                        $("#outputinput").html("");
                        $( "#htmlinput" ).text("");
                    break;
                    case 1:
                        $("#field2").css("display","none");
                    break;
                    case 2:
                        $("#field3").css("display","none");
                    break;
                    case 3:
                        $("#field4").css("display","none");
                    break;
                    default:
                    
                }
            }
            else{
                
                $(this).css("background-color","pink");
                switch(index) {
                    case 0:
                        $("#field1").css("display","block");
                    break;
                    case 1:
                        $("#field2").css("display","block");
                    break;
                    case 2:
                        $("#field3").css("display","block");
                    break;
                    case 3:
                        $("#field4").css("display","block");
                    break;
                    default:
                    
                }
            }
        });
        
    });
    $( "#htmlinput" ).keypress(function() {
            let tempHtml = $(this).text();
            $("#outputinput").html(tempHtml)
    });
    $("#cssinput" ).keypress(function() {
        let tempCss = $(this).text();
        var mySubString = tempCss.substring(
            tempCss.indexOf("{") + 1, 
            tempCss.lastIndexOf("}")
        );
        console.log(tempCss);
        
    });
    $( "#htmlinput" ).text(`<p id = "title"> nội dung html </p>`)
    $("#jsinput").text(`document.getElementById("title").onclick=function(){this.innerHTML="clicked"};`);
    $( "#htmlinput" ).keypress();
}

